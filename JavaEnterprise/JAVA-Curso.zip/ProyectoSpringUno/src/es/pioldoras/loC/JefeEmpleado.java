package es.pioldoras.loC;

public class JefeEmpleado implements Empleados{


	@Override
	public String getTareas() {
		// TODO Auto-generated method stub
		return "Gestinona las cuestiones relativas a mis empleados de sección";
	}
}
