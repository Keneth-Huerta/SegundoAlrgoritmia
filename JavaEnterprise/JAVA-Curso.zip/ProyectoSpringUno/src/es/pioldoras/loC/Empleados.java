package es.pioldoras.loC;

public interface Empleados {

	public String getTareas();
}
