package es.pioldoras.loC;

public class DirectorEmpleado implements Empleados {

	@Override
	public String getTareas() {
		// TODO Auto-generated method stub
		return "Gestionar la platilla de la empresa";
	}

}
