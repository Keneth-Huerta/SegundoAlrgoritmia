package mis_applets;

import javax.swing.JApplet;
import javax.swing.JLabel;

@SuppressWarnings("removal")
public class HolaAlumnos extends JApplet{

	public void init() {
		
		JLabel rotulo = new JLabel("Hola alumnons");
		add(rotulo);
	}
}
