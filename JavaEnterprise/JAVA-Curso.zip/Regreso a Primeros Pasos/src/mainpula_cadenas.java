import java.util.Scanner;
public class mainpula_cadenas {
	public static void main(String[] args) {

		System.out.println("Dime tu nombre por favor!");
		Scanner n=new Scanner(System.in);
		String nombre= n.nextLine();
		System.out.println("Mi nombre es "+nombre);
		
		System.out.println("Mi nombre tiene "+ nombre.length()+" letras.");
		System.out.println("La primera letra de "+nombre+" es la "+nombre.charAt(0));
		
		int ultima_letra=nombre.length();
		System.out.println("Y la ultima letra de "+nombre+" es la "+nombre.charAt(ultima_letra-1));
	}

}
