
public class Variables {

	public static void main(String[] args) {
		
		int edad;
		
		edad=4;
		edad+=3;
		System.out.println(edad);
	}
}
