public class Calculos_conMath {

	public static void main(String[] args) {

		double MarcoCambioEstado=-5;
						
		int resultado=(int)Math.abs(MarcoCambioEstado);
		
		System.out.println(MarcoCambioEstado);
	}
}
