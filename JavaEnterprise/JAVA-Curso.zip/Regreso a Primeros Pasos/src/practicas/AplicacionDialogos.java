package practicas;

public class AplicacionDialogos {

	public static void main(String[] args) {

		MarcoDialogos mimarco = new MarcoDialogos();
		mimarco.setVisible(true);
	}

}
