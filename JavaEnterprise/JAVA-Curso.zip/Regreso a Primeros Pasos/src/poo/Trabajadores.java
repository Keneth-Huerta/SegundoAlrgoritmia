package poo;

public interface Trabajadores {

	double estable_bonus(double gratificacion);

	double bonus_MarcoCambioEstado = 12800;
}
