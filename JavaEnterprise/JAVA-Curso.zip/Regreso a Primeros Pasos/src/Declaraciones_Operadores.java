public class Declaraciones_Operadores {

	public static void main(String[] args) {

		final double apulgadas=2.54;
		
		double cm =6;
		double resultado=cm/apulgadas;
		System.out.println("En "+cm+"cm hay "+resultado+" pulgadas");
	}

}
