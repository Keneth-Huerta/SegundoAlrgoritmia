import java.util.*;

public class Entrada_ejemplo1 {

	public static void main(String[] args) {

		System.out.println("Introduce tu nombre");
		Scanner entrada = new Scanner(System.in);
		
		String nombre=entrada.nextLine();
		
		System.out.println("Introduce tu edad, por favor");
		int edad=entrada.nextInt();
		
		System.out.println("Hola " + nombre+". El año que viene tendrás "+(edad+1)+" años");
		
	}

}
