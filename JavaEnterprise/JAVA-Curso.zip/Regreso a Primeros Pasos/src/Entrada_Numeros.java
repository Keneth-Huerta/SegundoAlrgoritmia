import javax.swing.JOptionPane;

public class Entrada_Numeros {

	public static void main(String[] args) {

//		double x=10000.0;
//		System.out.printf("%1.100f",x/3);
		String num1=JOptionPane.showInputDialog("Intrudce un número");
		double num2=Double.parseDouble(num1);
		System.out.print("La raíz de " +num2+" es ");
		System.out.printf("%1.25f",Math.sqrt(num2));
	}

}
