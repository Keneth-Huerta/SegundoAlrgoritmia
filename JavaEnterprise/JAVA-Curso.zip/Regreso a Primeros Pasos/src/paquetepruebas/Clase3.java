package paquetepruebas;

import poo.Clase1;

public class Clase3 extends Clase1{

	
}
