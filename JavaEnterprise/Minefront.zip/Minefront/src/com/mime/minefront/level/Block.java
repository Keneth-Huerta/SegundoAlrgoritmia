package com.mime.minefront.level;

public class Block {
	public boolean solid = false;

	public static Block solidWall = new SolidBlock();
	
}
