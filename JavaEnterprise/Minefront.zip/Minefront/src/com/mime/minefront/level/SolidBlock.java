package com.mime.minefront.level;

public class SolidBlock extends Block {

	public SolidBlock() {
		
		solid = true;
		
	}
	
}
