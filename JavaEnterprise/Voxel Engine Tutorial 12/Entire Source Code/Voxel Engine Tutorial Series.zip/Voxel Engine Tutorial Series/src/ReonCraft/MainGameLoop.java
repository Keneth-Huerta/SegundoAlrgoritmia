package ReonCraft;

import Minefront.Launcher;

public class MainGameLoop {
	
	
	public static void main(String[] args) {
		
		
		new Launcher(0);
	}
}
