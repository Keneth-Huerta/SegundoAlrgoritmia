

public class Lienzo {

	public static void main(String[] args) {

		VentanaLienzo miventa=new VentanaLienzo();
		miventa.setVisible(true);
	}

}
