package principal;

import vista.*;

public class EjecutaModeloVisaControlador {

	public static void main(String[] args) {
		
		MarcoAplicacion mimarco=new MarcoAplicacion();	
		mimarco.setVisible(true);
	}
}
