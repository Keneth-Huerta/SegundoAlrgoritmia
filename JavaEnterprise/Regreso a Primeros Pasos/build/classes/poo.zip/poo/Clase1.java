package poo;

public class Clase1 {

	protected int mivar = 5;

	protected int mivar2 = 7;

	protected String mimetodo() {
		return "El valor de mivar2 es: " + mivar2;
	}
}
