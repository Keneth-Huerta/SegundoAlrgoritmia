package poo;

public interface Jefes extends Trabajadores {

	String tomar_decisiones(String decision);
}
